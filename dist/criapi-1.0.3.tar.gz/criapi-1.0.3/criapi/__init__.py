__title__ = 'criapi'
__version__ = '1'
__author__ = 'Saksham Arya'
__license__ = 'GPLv3'

from criapi.__main__ import Cricbuzz